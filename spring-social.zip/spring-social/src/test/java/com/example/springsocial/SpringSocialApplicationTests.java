package com.example.springsocial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSocialApplicationTests {

	@Test
	void contextLoads() {
	}

}
